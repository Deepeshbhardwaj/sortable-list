import React from 'react';
import { Draggable } from 'react-beautiful-dnd';

interface Item {
  id: string;
  name: string;
  quantity: number;
}

interface SortableItemProps {
  item: Item;
  index: number;
  onDelete: (id: string) => void;
  onNameChange: (id: string, name: string) => void;
  onQuantityChange: (id: string, quantity: number) => void;
}

const SortableItem: React.FC<SortableItemProps> = ({ item, index, onDelete, onNameChange, onQuantityChange }) => (
  <Draggable draggableId={item.id} index={index}>
    {(provided) => (
      <div
        ref={provided.innerRef}
        {...provided.draggableProps}
        {...provided.dragHandleProps}
      >
        <div className="item">
          <input
            type="text"
            value={item.name}
            onChange={(e) => onNameChange(item.id, e.target.value)}
            placeholder="Item Name"
          />
          <select value={item.quantity} onChange={(e) => onQuantityChange(item.id, parseInt(e.target.value))}>
            {[...Array(12).keys()].map((num) => (
              <option key={num + 1} value={num + 1}>
                {num + 1}
              </option>
            ))}
          </select>
          <button onClick={() => onDelete(item.id)}>Delete</button>
        </div>
      </div>
    )}
  </Draggable>
);

export default SortableItem;
