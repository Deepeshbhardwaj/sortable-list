// App.tsx
import React, { useState } from 'react';
import { DragDropContext } from 'react-beautiful-dnd';
import SortableList from './SortableList';
import Modal from './Modal';
import './App.css';

interface Item {
  id: string;
  name: string;
  quantity: number;
}

const App: React.FC = () => {
  const [listName, setListName] = useState<string>('');
  const [listType, setListType] = useState<string>('');
  const [items, setItems] = useState<Item[]>([]);
  const [modalOpen, setModalOpen] = useState<boolean>(false);

  const handleAddItem = () => {
    const newItem: Item = {
      id: `item-${items.length + 1}`,
      name: '',
      quantity: 1
    };
    setItems([...items, newItem]);
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleNameChange = (id: string, name: string) => {
    setItems(items.map(item => item.id === id ? { ...item, name: name } : item));
  };

  const handleQuantityChange = (id: string, quantity: number) => {
    setItems(items.map(item => item.id === id ? { ...item, quantity: quantity } : item));
  };

  const handleSave = () => {
    // Perform validation
    if (listName.trim() === '' || listType.trim() === '') {
      alert('List Name and Type are required.');
      return;
    }

    if (items.some(item => item.name.trim() === '' || item.quantity <= 0)) {
      alert('Please ensure each item has a name and quantity.');
      return;
    }

    // Perform save operation
    setModalOpen(true);
  };

  const onCloseModal = () => {
    setModalOpen(false);
  };

  const onDragEnd = () => {
    // Handle drag and drop end
  };

  return (
    <div className="App">
      <h1>Shopping List</h1>
      <input type="text" value={listName} onChange={(e) => setListName(e.target.value)} placeholder="List Name" />
      <select value={listType} onChange={(e) => setListType(e.target.value)}>
        <option value="">Select Type</option>
        <option value="Grocery">Grocery</option>
        <option value="Home Goods">Home Goods</option>
        <option value="Hardware">Hardware</option>
      </select>
      <button onClick={handleAddItem}>Add an Item</button>
      <DragDropContext onDragEnd={onDragEnd}>
        <SortableList
          items={items}
          onDelete={handleDeleteItem}
          onNameChange={handleNameChange}
          onQuantityChange={handleQuantityChange}
        />
      </DragDropContext>
      <button onClick={handleSave}>Save List</button>
      <Modal isOpen={modalOpen} onClose={onCloseModal} />
    </div>
  );
};

export default App;
