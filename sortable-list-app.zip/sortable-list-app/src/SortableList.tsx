import React from 'react';
import { Droppable } from 'react-beautiful-dnd';
import SortableItem from './SortableItem';

interface Item {
  id: string;
  name: string;
  quantity: number;
}

interface SortableListProps {
  items: Item[];
  onDelete: (id: string) => void;
  onNameChange: (id: string, name: string) => void;
  onQuantityChange: (id: string, quantity: number) => void;
}

const SortableList: React.FC<SortableListProps> = ({ items, onDelete, onNameChange, onQuantityChange }) => (
	<div>
	  {items.map((item, index) => (
		<Droppable key={item.id} droppableId={item.id}>
		  {(provided) => (
			<div ref={provided.innerRef} {...provided.droppableProps}>
			  <SortableItem
				key={item.id}
				item={item}
				index={index}
				onDelete={onDelete}
				onNameChange={onNameChange}
				onQuantityChange={onQuantityChange}
			  />
			  {provided.placeholder}
			</div>
		  )}
		</Droppable>
	  ))}
	</div>
  );
  

export default SortableList;
